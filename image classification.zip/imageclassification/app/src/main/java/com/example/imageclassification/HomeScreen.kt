package com.example.imageclassification

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class HomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_screen)

        supportActionBar?.hide()
        //First button
        val b1 = findViewById<Button>(R.id.b1)
        b1.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        //Second button
//        val b2 = findViewById<Button>(R.id.b2)
//        b2.setOnClickListener {
//            val intent2 = Intent(this, T2S::class.java)
//            startActivity(intent2)
//        }
        //Third button
        val b3 = findViewById<Button>(R.id.b3)
        b3.setOnClickListener {
            val intent3 = Intent(this, T2S::class.java)
            startActivity(intent3)
        }
    }

}